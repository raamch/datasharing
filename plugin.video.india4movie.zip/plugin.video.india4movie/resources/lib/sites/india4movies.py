from resources.lib.abc_base import BaseI4M


class India4MovieApi(BaseI4M):

    BASE_URL = 'http://www.india4movie.co/'
    SHORT_NAME = 'i4m'
    LONG_NAME = 'India 4 Movie'
    LOCAL_THUMB = 'thumb_india4movies.png'

###############################################
